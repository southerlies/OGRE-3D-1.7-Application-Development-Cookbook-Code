#include "Ogre\ExampleApplication.h"



class Example41 : public ExampleApplication
{
public:

	void createScene()
	{
		
	}
	
};

int main (void)
{
	Example41 app;
	app.go();
	return 0;
}
